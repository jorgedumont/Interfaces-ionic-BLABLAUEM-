import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recargarautomatico',
  templateUrl: './recargarautomatico.page.html',
  styleUrls: ['./recargarautomatico.page.scss'],
})
export class RecargarautomaticoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
