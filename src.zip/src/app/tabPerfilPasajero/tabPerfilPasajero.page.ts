import { Component } from '@angular/core';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tabPerfilPasajero.page.html',
  styleUrls: ['tabPerfilPasajero.page.scss']
})
export class Tab1Page {

  constructor() {}

}
