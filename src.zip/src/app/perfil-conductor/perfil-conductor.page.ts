import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-perfil-conductor',
  templateUrl: './perfil-conductor.page.html',
  styleUrls: ['./perfil-conductor.page.scss'],
})
export class PerfilConductorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
