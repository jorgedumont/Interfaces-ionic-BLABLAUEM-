import { Component } from '@angular/core';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tabAjustesConductor.page.html',
  styleUrls: ['tabAjustesConductor.page.scss']
})
export class Tab3Page {

  constructor() {}

}
