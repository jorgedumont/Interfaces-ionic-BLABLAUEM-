import { Component } from '@angular/core';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabsPasajero.page.html',
  styleUrls: ['tabsPasajero.page.scss']
})
export class TabsPage {

  constructor() {}

}
