import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-metodopago',
  templateUrl: './metodopago.page.html',
  styleUrls: ['./metodopago.page.scss'],
})
export class MetodopagoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
