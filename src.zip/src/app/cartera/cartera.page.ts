import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cartera',
  templateUrl: './cartera.page.html',
  styleUrls: ['./cartera.page.scss'],
})
export class CarteraPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
