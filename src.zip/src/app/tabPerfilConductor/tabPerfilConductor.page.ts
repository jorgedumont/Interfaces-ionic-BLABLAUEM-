import { Component } from '@angular/core';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tabPerfilConductor.page.html',
  styleUrls: ['tabPerfilConductor.page.scss']
})
export class Tab1Page {

  constructor() {}

}
