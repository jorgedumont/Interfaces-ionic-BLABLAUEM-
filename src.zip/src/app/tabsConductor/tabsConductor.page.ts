import { Component } from '@angular/core';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabsConductor.page.html',
  styleUrls: ['tabsConductor.page.scss']
})
export class TabsPage {

  constructor() {}

}
