import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usuario-conductor',
  templateUrl: './usuario-conductor.page.html',
  styleUrls: ['./usuario-conductor.page.scss'],
})
export class UsuarioConductorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  

}
