import { Component } from '@angular/core';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tabAjustesPasajero.page.html',
  styleUrls: ['tabAjustesPasajero.page.scss']
})
export class Tab3Page {

  constructor() {}

}
