import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listacoches',
  templateUrl: './listacoches.page.html',
  styleUrls: ['./listacoches.page.scss'],
})
export class ListacochesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
