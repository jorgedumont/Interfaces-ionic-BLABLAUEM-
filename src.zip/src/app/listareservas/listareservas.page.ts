import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listareservas',
  templateUrl: './listareservas.page.html',
  styleUrls: ['./listareservas.page.scss'],
})
export class ListareservasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
