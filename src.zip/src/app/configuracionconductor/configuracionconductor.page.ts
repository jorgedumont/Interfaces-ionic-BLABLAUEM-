import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configuracionconductor',
  templateUrl: './configuracionconductor.page.html',
  styleUrls: ['./configuracionconductor.page.scss'],
})
export class ConfiguracionconductorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
