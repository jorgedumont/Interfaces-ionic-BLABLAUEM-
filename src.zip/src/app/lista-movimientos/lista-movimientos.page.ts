import { Component } from '@angular/core';

@Component({
  selector: 'app-lista-movimientos',
  templateUrl: './lista-movimientos.page.html',
  styleUrls: ['./lista-movimientos.page.scss'],
})
export class ListaMovimientosPage {

  constructor() { }

  doRefresh(event) {
    console.log('Begin async operation');

    setTimeout(() => {
      console.log('Async operation has ended');
      event.target.complete();
    }, 2000);
  }

}
